§align:center
##### §nAwakened Core§n

§stack[draconicevolution:awakened_core]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
The next tier up from Wyvern, this core is used in most tier 3 (Draconic) crafting recipes.

Yes, I know the tier naming is confusing because the base core is also called the Draconic Core. See the note on the Draconic Core page for an explaination on why it has that name.

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:awakened_core]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}