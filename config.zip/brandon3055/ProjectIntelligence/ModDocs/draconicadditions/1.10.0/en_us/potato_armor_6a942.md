§align:center
##### §nEnergized Potato Armor§n

The Energized Potato Armor is designed to get you up and running with draconic shielding before you have to kill a wither.  However, just because you can acquire shielding early on, don't think that you're invincible because of it!  Energized Potato Armor comes with a few downsides compared to the §link[draconicevolution:wyvern_armor]{alt_text:"Wyvern Armor"}.

First, it cannot be recharged.  It starts fully charged, but over time will lose it's charge as you use it, until finally, it breaks down!

Second, it has no secondary benefits, such as speed boosts or jump boosts.  Potatos aren't that nutritious, you know!

Lastly, it provides very minimal armor, even worse than leather.  If enemies do get through it's shields, it's not going to protect you very well.