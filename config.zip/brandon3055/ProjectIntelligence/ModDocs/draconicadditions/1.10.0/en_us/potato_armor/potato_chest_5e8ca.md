§align:center
##### §nEnergized Potato Chestplate

§stack[draconicadditions:potato_chest]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§bStats

+6.4 Base Shield Capacity
+2 Armor

§rule{colour:0x606060,height:3,width:100%,top_pad:0}

In order to get this item, you must drop, shake (right-click), or smack a mob with an §link[draconicadditions:infused_potato_armor/infused_potato_chest]{alt_text:"Infused Potato Chestplate"}.

§oNote: Modpack authors may disable one or all of these methods of transformation.  In this case, potential recipes are listed below.

§recipe[draconicadditions:potato_chest]{spacing:4}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}