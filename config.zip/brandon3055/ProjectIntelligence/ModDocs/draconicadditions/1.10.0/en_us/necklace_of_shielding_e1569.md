§align:center
##### §nNecklaces of Shielding§n

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
Necklaces of Shielding provide you with some very basic shielding, but what makes them better than the §link[draconicadditions:potato_armor]{alt_text:"Potato Armor"} is that they can be recharged!  Not only that, but they can also stack with your existing shielding, augmenting your shields further than ever before!