§align:center
##### §nЭнергетическе реле-кристаллы§n
§stack[draconicevolution:energy_crystal,1,0]{size:64} §stack[draconicevolution:energy_crystal,1,1]{size:64} §stack[draconicevolution:energy_crystal,1,2]{size:64}
§rule{colour:0x606060,height:3,width:100%,top_pad:0}
###### §nХарактеристики:

§9Базовый§r
Ёмкость: 4 миллиона
Макс. количество соединений: 8 

§5Виверны§r
Ёмкость: 16 миллионов
Макс. количество соединений: 16 

§6Дракона§r
Ёмкость: 64 миллиона
Макс. количество соединений: 32

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:energy_crystal,1,0]{spacing:2}§recipe[draconicevolution:energy_crystal,1,1]{spacing:2}§recipe[draconicevolution:energy_crystal,1,2]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}