§align:center
##### §nНагрудник Виверны§n

§stack[draconicevolution:wyvern_chest]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§bХарактеристики:

+80 к основной ёмкости щита
+2 к прочности брони
+8 к очкам защиты

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:wyvern_chest]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}