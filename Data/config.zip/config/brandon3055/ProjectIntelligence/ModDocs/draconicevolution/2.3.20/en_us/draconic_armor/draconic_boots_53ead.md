§align:center
##### §nDraconic Boots§n

§stack[draconicevolution:draconic_boots]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§bStats

+76 Base Shield Capacity
+3 Armor Toughness
+3 Armor
Immune to Fall Damage
Jump boost (Configurable)
Uphill Step Assist (Configurable)

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:draconic_boots]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}