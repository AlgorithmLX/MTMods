§align:center
##### §nДатчик дождя§n

§stack[draconicevolution:rain_sensor]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
Это устройство излучает редстоун-сигнал во время дождя.
Идеально подойдёт в качестве активатора для контроллера погоды.
(Для работы должен иметь открытое небо над собой)

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:rain_sensor]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}