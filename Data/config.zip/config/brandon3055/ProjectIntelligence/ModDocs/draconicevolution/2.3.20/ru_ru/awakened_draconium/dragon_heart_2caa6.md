§align:center
##### §nСердце Дракона§n

§stack[draconicevolution:dragon_heart]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
Выпадает при убийстве Эндер-дракона и Хранителя Хаоса.
Этот невероятно мощный предмет используется для создания §link[draconicevolution:awakened_draconium]{alt_text:"Пробуждённого Дракония"}. 

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:dragon_heart]{spacing:2}