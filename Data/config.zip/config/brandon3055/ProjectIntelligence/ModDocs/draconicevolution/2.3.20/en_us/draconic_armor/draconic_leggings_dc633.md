§align:center
##### §nDraconic Leggings§n

§stack[draconicevolution:draconic_legs]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§bStats

+153 Base Shield Capacity
+3 Armor Toughness
+6 Armor
Speed Boost (Configurable)

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:draconic_legs]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}