§align:center
##### §nПробуждённое ядро§n

§stack[draconicevolution:awakened_core]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
Ядро третьего уровня.  Используется в довольно сложных рецептах, например для создания инструментов и оружия Дракона.

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:awakened_core]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}