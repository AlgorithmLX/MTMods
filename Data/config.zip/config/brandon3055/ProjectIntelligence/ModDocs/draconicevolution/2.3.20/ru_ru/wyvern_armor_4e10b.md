§align:center
##### §nБроня Виверны§n

Броня Виверны - ваш первый шаг к идеальному комплекту брони!

На первый взгляд может показаться, что броня в Draconic Evolution имеют довольно слабые характеристики. Фактически, эти характеристики не являются её основной линиеё защиты. Вся броня в DE имеет мощный §link[draconicevolution:draconic_energy_shield]{alt_text:"Энергетический Щит Дракона"},  который способен поглощать огромное количество урона.

Некоторые части брони имеют настраиваемые опции в графическом интерфейсе DE.

Ношение полного сета Виверны даёт 100% огнестойкость.  

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§img[https://raw.githubusercontent.com/brandon3055/Project-Intelligence-Docs/master/Assets/Draconic%20Evolution/Armor/Wyvern%20Armor.jpg]{width:30%} 
§rule{colour:0x606060,height:3,width:100%}