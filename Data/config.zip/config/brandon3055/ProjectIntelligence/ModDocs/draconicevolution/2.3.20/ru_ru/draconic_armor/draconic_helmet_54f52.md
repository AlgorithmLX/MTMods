§align:center
##### §nШлем Дракона§n

§stack[draconicevolution:draconic_helm]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§bХарактеристики:

-Ночное зрение
-Убирает отрицательные эффекты от зелий
-Поглощает урон от удушения или утопления
Убирает замедления копания под водой (Родство с водой)
+60 к основной ёмкости щита
+3 к прочности брони
+3 к очкам защиты

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:draconic_helm]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}