§align:center
##### §nИнжекторы слияния§n

§stack[draconicevolution:crafting_injector]{size:42} §stack[draconicevolution:crafting_injector,1,1]{size:42} §stack[draconicevolution:crafting_injector,1,2]{size:42} §stack[draconicevolution:crafting_injector,1,3]{size:42}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
Инжекторы слияния являются ключевым компонентом в процессе слияния. Они используются для удержания предметов, которые должны быть объединены с катализатором в Ядре. Посетите вкладку §link[draconicevolution:fusion_crafting/fusion_crafting_setup]{alt_text:"Постройка конструкции слияния"} для получения информации.

Вы можете кликнуть ПKМ по инжектору пустой рукой, чтобы перевести его в режим "одиночный предмет". Как и следует из названия, находясь в этом режиме, инжектор будет принимать только один предмет, что может быть полезно при автоматизации процесса слияния.
§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:crafting_injector]{spacing:2} §recipe[draconicevolution:crafting_injector,1,1]{spacing:2} §recipe[draconicevolution:crafting_injector,1,2]{spacing:2} §recipe[draconicevolution:crafting_injector,1,3]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}