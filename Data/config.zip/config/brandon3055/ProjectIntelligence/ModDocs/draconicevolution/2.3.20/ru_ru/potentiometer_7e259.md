§align:center
##### §nПотенциометр§n

§stack[draconicevolution:potentiometer]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
Простое устройство, способное излучать редстоун-сигналы с силой от 0 до 15.

§img[http://ss.brandon3055.com/bd604]{width:100%} 
§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:potentiometer]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}