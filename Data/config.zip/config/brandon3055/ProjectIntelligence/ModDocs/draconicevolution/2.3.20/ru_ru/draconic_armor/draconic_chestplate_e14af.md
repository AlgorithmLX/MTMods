§align:center
##### §nНагрудник Дракона§n

§stack[draconicevolution:draconic_chest]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§bХарактеристики:

-Полёт (с регулируемой скоростью)
-Убирает замедление копания в воздухе
-Иммунитет к огню
+200 к базовой ёмкости щита
+3 к прочности брони
+8 к очкам защиты

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:draconic_chest]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}