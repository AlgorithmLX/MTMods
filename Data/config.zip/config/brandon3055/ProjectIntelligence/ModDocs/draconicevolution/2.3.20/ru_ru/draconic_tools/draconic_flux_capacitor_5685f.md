§align:center
##### §nФлаксовый конденсатор Дракона§n

§stack[draconicevolution:draconium_capacitor,1,1]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
Этот конденсатор имеет тот же функционал что и §link[draconicevolution:wyvern_tools/wyvern_flux_capacitor]{alt_text:"Флаксовый конденсатор Виверны"}. Имеет базовую емкость в 256 миллиона RF, которую впоследствии можно улучшить до 640 миллионов.

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:draconium_capacitor,1,1]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}