§align:center
##### §nDraconic Chestplate§n

§stack[draconicevolution:draconic_chest]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§bStats

+204 Base Shield Capacity
+3 Armor Toughness
+8 Armor
Flight (Configurable)
Removes mining slowdown while in the air
Immune to Fire Damage

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:draconic_chest]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}