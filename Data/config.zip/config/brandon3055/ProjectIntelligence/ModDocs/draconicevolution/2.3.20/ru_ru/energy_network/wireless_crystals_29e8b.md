§align:center
##### §nБеспроводные энергетические кристаллы§n
§stack[draconicevolution:energy_crystal,1,6]{size:64} §stack[draconicevolution:energy_crystal,1,7]{size:64} §stack[draconicevolution:energy_crystal,1,8]{size:64}
§rule{colour:0x606060,height:3,width:100%,top_pad:0}
###### §nХарактеристики:

§9Базовый§r
Ёмкость: 4 миллиона
Макс. количество соединений: 4
Макс. количество беспроводных соединений: 16

§5Виверны§r
Ёмкость: 16 миллионов
Макс. количество соединений:: 8
Макс. количество беспроводных соединений: 32

§6Дракона§r
Ёмкость: 64 миллиона
Макс. количество соединений: 16
Макс. количество беспроводных соединений: 64

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:energy_crystal,1,6]{spacing:2}§recipe[draconicevolution:energy_crystal,1,7]{spacing:2}§recipe[draconicevolution:energy_crystal,1,8]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}