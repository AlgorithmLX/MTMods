§align:center
##### §nБотинки Дракона§n

§stack[draconicevolution:draconic_boots]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§bХарактеристики:

-Защита от падения
-Увеличение высоты прыжка
-Авто-подъём: позволяет Вам, не прыгая, взобраться на блок выше.
+60 к базовой ёмкости щита
+3 к прочности брони
+3 к очкам защиты

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:draconic_boots]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}