§align:center

§ЭЭнергетическое ядро Виверны§n
§stack[draconicevolution:wyvern_energy_core]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0} Компонент для создания всех предметов Виверны, которые используют RF.

§rule{colour:0x606060,height:3,width:100%,top_pad:0} §recipe[draconicevolution:wyvern_energy_core]{spacing:2} §rule{colour:0x606060,height:3,width:100%,top_pad:3}