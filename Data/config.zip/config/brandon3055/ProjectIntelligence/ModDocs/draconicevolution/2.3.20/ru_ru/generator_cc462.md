§align:center
##### §nГенератор§n

§stack[draconicevolution:generator]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
Это простейший генератор слабой мощности, который пережигает большиство источников топлива и производит 84RF/t.

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:generator]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}