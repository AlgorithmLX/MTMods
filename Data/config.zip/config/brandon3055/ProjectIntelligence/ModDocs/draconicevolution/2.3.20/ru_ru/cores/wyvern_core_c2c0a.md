§align:center
##### §nЯдро Виверны§n

§stack[draconicevolution:wyvern_core]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
Ядро второго уровня. Используется в более продвинутых рецептах.

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:wyvern_core]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}