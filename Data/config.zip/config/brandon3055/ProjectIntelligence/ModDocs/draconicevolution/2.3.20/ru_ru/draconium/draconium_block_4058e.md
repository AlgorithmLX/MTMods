§align:center
##### §nДракониевый блок§n

§stack[draconicevolution:draconium_block]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
Собственно, Драконий в форме блока.
Устойчив к большинству существ, включая Визера и Эндер-дракона.
При использовании в качестве усилителя зачарований эквивалентен 4-м книжным полкам.

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:draconium_block]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}