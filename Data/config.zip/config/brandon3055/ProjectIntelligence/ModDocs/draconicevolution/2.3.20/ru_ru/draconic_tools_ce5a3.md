§align:center
##### §nИнструменты Дракона§n

§stack[draconicevolution:draconic_pick]{size:32} §stack[draconicevolution:draconic_axe]{size:32} §stack[draconicevolution:draconic_shovel]{size:32} §stack[draconicevolution:draconic_hoe]{size:32} §stack[draconicevolution:draconic_sword]{size:32} §stack[draconicevolution:draconic_bow]{size:32} §stack[draconicevolution:draconic_staff_of_power]{size:32} §stack[draconicevolution:draconium_capacitor,1,1]{size:32}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
Эти инструменты и оружие находятся на вершине Draconic Evolution.

Они перенимают все возможности инструментов Виверны, но с несколькими значительными улучшениями. 

§6§nРегулируемая глубина добычи.§r
Эту настройку имеют все добывающие инструменты Дракона.
Это означает, что Вы сможете, к примеру, вскопать куб 5х5х5.

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§img[https://raw.githubusercontent.com/brandon3055/Project-Intelligence-Docs/master/Assets/Draconic%20Evolution/Tools/Draconic%20Tools.jpg]{tooltip:"The wyvern toolset uses custom 3D models when rendered in game.",width:100%}
§rule{colour:0x606060,height:3,width:100%}