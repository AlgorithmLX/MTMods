§align:center
##### §nЛопата Дракона§n

§img[http://ss.brandon3055.com/70bf2]{width:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§b§nХарактеристики:

§6Емкость - 16 миллионов RF. Можно улучшить до 256 миллионов.

§6Базовая область добычи: 3x3. Можно улучшить до 9x9.

§6Глубина добычи: 3 блока. Можно улучшить до 9.

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:draconic_shovel]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}