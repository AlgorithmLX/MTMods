§align:center
##### §nЭнергетические кристаллы входа/выхода§n
§stack[draconicevolution:energy_crystal,1,3]{size:64} §stack[draconicevolution:energy_crystal,1,4]{size:64} §stack[draconicevolution:energy_crystal,1,5]{size:64}
§rule{colour:0x606060,height:3,width:100%,top_pad:0}
###### §nХарактеристики:

§9Базовый§r
Ёмкость: 4 миллиона
Макс. количество соединений: 2 

§5Виверны§r
Ёмкость: 16 миллионов
Макс. количество соединений: 3

§6Дракона§r
Ёмкость: 64 миллиона
Макс. количество соединений: 4

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:energy_crystal,1,3]{spacing:2}§recipe[draconicevolution:energy_crystal,1,4]{spacing:2}§recipe[draconicevolution:energy_crystal,1,5]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}