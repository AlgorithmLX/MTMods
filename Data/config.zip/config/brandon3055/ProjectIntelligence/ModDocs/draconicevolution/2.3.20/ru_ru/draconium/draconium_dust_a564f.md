§align:center
##### §nДракониевая Пыль§n

§stack[draconicevolution:draconium_dust]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
Дракониевая пыль выпадает при добыче §link[draconicevolution:draconium/draconium_ore]{alt_text:Дракониевой Руды}. Одну пыль можно переплавить в один §link[draconicevolution:draconium]{alt_text:Дракониевый слиток}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:draconium_dust]{spacing:2}