§align:center
##### §nЯдро Хаоса§n

§stack[draconicevolution:chaotic_core]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
Готовы ли вы к испытаниям? Если да, тогда попытайтесь бросить вызов §link[draconicevolution:chaos_guardian]{alt_text:"Хранителю Хаоса"}, так как это может стоить того!

На данный момент осколки хаоса мало где используются, но если вы любитель безумного производства энергии, то вам стоит посмотреть §link[draconicevolution:draconic_reactor]{alt_text:"Дракониевый Реактор"}!

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:chaotic_core]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}