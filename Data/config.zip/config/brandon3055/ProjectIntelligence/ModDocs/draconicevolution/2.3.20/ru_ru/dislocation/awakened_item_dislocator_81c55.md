§align:center
##### §nПробуждённый телепортационный магнит§n

§stack[draconicevolution:magnet,1,1]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
Это улучшенный телепортационный магнит с радиусом действия в 32 блока!

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:magnet,1,1]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}