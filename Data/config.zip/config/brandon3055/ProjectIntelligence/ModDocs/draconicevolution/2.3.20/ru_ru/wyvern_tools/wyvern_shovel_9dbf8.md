§align:center
##### §nЛопата Виверны§n

§img[http://ss.brandon3055.com/84c07]{width:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§b§nХарактеристики:

§6Емкость - 4 миллиона RF. Можно улучшить до 32 миллионов.

§6Базовая область добычи: 1x1. Можно улучшить до 5x5.

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:wyvern_shovel]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}