§align:center
##### §nПоножи Дракона§n

§stack[draconicevolution:draconic_legs]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§bХарактеристики:

-Ускорение бега
+180 к базовой ёмкости щита
+3 к прочности брони
+6 к очкам защиты

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:draconic_legs]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}