§align:center
##### §nWyvern Sword§n

§img[http://ss.brandon3055.com/38ce7]{width:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§b§nStats

§64M max RF - Upgradable to 32M.

§615 base Attack - Upgradable to 22.5.

§6Attack radius can be upgraded to 5x5.

Note: the AOE attack only works when the sword is fully charged.
(Referring to the vanilla charging/cooldown mechanic)

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:wyvern_sword]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}