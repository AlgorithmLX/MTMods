§align:center
##### §nБроня Дракона§n

Броня Дракона - это лучшая броня! Эта броня имеет улучшенные характеристики в отличии от брони Виверны, а также имеет несколько новых характеристик!

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§img[https://raw.githubusercontent.com/brandon3055/Project-Intelligence-Docs/master/Assets/Draconic%20Evolution/Armor/Draconic%20Armor.jpg]{width:30%} 
§rule{colour:0x606060,height:3,width:100%}