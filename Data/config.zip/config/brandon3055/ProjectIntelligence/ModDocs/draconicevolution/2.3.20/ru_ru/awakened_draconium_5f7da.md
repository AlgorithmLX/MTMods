§align:center
##### §nПробуждённый Драконий§n

§stack[draconicevolution:nugget,1,1]{size:32} §stack[draconicevolution:draconic_ingot]{size:32} §stack[draconicevolution:draconic_block]{size:32}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
Пробужденный Драконий - ваш следующий шаг к созданию еще более мощных инструментов, оружия и брони!

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:draconic_ingot]{spacing:2}§recipe[draconicevolution:draconic_block]{spacing:2}§recipe[draconicevolution:nugget,1,1]{spacing:2}§recipe[draconicevolution:draconium_dust]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:0}