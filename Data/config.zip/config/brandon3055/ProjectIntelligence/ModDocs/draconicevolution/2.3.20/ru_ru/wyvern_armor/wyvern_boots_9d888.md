§align:center
##### §nБотинки Виверны§n

§stack[draconicevolution:wyvern_boots]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§bХарактеристики:

+20 к основной ёмкости щита
+2 к прочности брони
+3 к очкам защиты
+Уменьшенный урон от падений
+Увеличение прыжка

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:wyvern_boots]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}