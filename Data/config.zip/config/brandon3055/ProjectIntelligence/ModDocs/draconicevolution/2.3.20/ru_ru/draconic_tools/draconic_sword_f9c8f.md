§align:center
##### §nМеч Дракона§n

§img[http://ss.brandon3055.com/a6278]{width:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§b§nХарактеристики:

§6Емкость - 16 миллионов RF. Можно улучшить до 256 миллионов.

§6Базовый радиус атаки: 3x3. Можно улучить до 13x13.
Обратите внимание, что Атака по области работает только тогда, когда меч полностью заряжен.
(В виду новой ванильной механики зарядки).

§6Базовая атака: 35 урона. Можно улучшить до 61.25.

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:draconic_sword]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}