§align:center
##### §nЯдра§n

§stack[draconicevolution:draconic_core]{size:32} §stack[draconicevolution:wyvern_core]{size:32} §stack[draconicevolution:awakened_core]{size:32} §stack[draconicevolution:chaotic_core]{size:32}

§stack[draconicevolution:wyvern_energy_core]{size:32} §stack[draconicevolution:draconic_energy_core]{size:32}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
Ядра являются компонентами почти всех рецептов Draconic Evolution.
Существует 4 уровня ядер: Дракона (он же базовый) - самый низкий, а уровень Хаоса - самый высокий. Уровень ядра, используемого в рецепте создания, зависит от уровня самого создаваемого предмета.

В дополнение к 4 обычным ядрам, существует ещё 2 типа Энергетических Ядер. Они в основном используются для создания всего, что накапливает энергию, например, инструментов.

Также обратите внимание, что вы можете щелкнуть ПКМ по ванильному спаунеру любым ядром, чтобы превратить его в §link[draconicevolution:stabilized_spawner]{alt_text:"Стабилизированный Спаунер"}.
§rule{colour:0x606060,height:3,width:100%,top_pad:0}