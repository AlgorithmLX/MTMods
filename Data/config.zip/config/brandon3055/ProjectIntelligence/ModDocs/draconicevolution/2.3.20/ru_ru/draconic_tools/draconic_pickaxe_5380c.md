§align:center
##### §nКирка Дракона§n

§img[http://ss.brandon3055.com/ea55c]{width:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§b§nХарактеристики:

§6Емкость - 16 миллионов RF. Можно улучшить до 256 миллионов.

§6Базовая область добычи: 3x3. Можно улучшить до 9x9.

§6Глубина добычи: 3 блока. Можно улучшить до 9.

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:draconic_pick]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}