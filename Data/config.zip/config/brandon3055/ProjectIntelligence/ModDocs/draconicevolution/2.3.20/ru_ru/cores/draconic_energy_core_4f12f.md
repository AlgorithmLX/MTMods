§align:center
##### §nЭнергетическое ядро Дракона§n

§stack[draconicevolution:draconic_energy_core]{size:64}

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
Это более мощная версия §link[draconicevolution:cores/wyvern_energy_core]{alt_text:"Энергетического ядра Виверны"}, используемая в рецептах создания более высокого уровня.

§rule{colour:0x606060,height:3,width:100%,top_pad:0}
§recipe[draconicevolution:draconic_energy_core]{spacing:2}
§rule{colour:0x606060,height:3,width:100%,top_pad:3}